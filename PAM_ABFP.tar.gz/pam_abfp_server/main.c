/* 
 * File:   main.c
 * Author: jurgen
 *
 * Created on July 9, 2013, 1:30 AM
 */

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <db.h>
#include <time.h> 
#include <pthread.h>
#include <signal.h>
#include <math.h>

#define BLOCK "block"
#define CRYP "pam_abfp"

DB *htdb;

/* opens the database
 */
int dbopen(const char *dbfile, const char *dbname, DB **db) {
    int err;

    // creates the database
    if (err = db_create(db, NULL, 0), 0 != err) {
        printf("Error creating database object");
        return err;
    }

    // opens the database
    if (err = (*db)->open(*db, NULL, dbfile, dbname, DB_BTREE,
            DB_CREATE, 0600), 0 != err) {
        printf("Error opening database");
        return err;
    }
    return 0;
}

/* Grow the buffer of a DBT if necessary
 */
int grow_buffer(DBT *dbt, u_int32_t minsize) {
    if (dbt->ulen < minsize) {
        void *nd;
        if (nd = realloc(dbt->data, minsize), NULL == nd) {
            printf("allocating record buffer");
            return -1;
        }
        dbt->data = nd;
        dbt->ulen = minsize;
    }
    return 0;
}

/* make key for database
 */
void make_key(DBT *dbt, const char *key) {
    memset(dbt, 0, sizeof (*dbt));
    dbt->data = (void *) key;
    dbt->size = strlen(key) + 1;
    dbt->ulen = dbt->size + 1;
}

/* gets the value of a key
 */
int dbget(DB *db, DBT *key, DBT *dbtdata) {
    int err;

    // sets memory
    memset(dbtdata, 0, sizeof (*dbtdata));
    dbtdata->flags = DB_DBT_USERMEM;

    // reads from the db
    err = db->get(db, NULL, key, dbtdata, 0);

    // if called with DB_DBT_USERMEM, grow buffer
    if (DB_BUFFER_SMALL == err) {
        if (err = grow_buffer(dbtdata, dbtdata->size), 0 != err) {
            return err;
        }
        dbtdata->size = 0;
        // try again, now buffer should be big enough
        err = db->get(db, NULL, key, dbtdata, 0);
    }

    // if not found return
    if (0 != err && DB_NOTFOUND != err) {
        return err;
    }
    // if db not found return and set size to zero
    if (DB_NOTFOUND == err) {
        dbtdata->size = 0;
    }
    // else return
    return err;
}

/* read the databse if there is already a record
 */
int read_db(DB *htdb, char * ipadd) {
    DB *db;
    DBT key, value;
    int ret = 0;
    const char *kv;

    db = htdb;
    kv = ipadd;
    memset(&key, 0, sizeof (DBT));
    memset(&value, 0, sizeof (DBT));

    make_key(&key, kv);
    // try to get record
    ret = dbget(db, &key, &value);

    if (ret != 0) {
        return 1;
    } else return 0;


}

/* add record to database
 */
int db_add(DB *htdb, char *ipadd) {
    DB *db;
    DBT key, value;
    const char *kv;
    int ret;
    time_t tnow = time(NULL);
    FILE *log;
    char buffer[100];

    db = htdb;
    kv = ipadd;

    memset(&key, 0, sizeof (DBT));
    memset(&value, 0, sizeof (DBT));
    make_key(&key, kv);
    // is there already an entry
    ret = dbget(db, &key, &value);
    if (0 != ret && DB_NOTFOUND != ret) {
        return ret;
    }
    // if db is not found return
    if (DB_NOTFOUND == ret) {
        value.size = 0;
    }
    // grow buffer if it's too small
    if (ret = grow_buffer(&value, value.size + sizeof (time_t)), 0 != ret) {
        return ret;
    }
    // make enough space
    memcpy((char *) value.data + value.size, &tnow, sizeof (time_t));
    value.size += sizeof (time_t);
    // put into db and paste it to the log
    ret = db->put(db, NULL, &key, &value, 0);
    log = fopen("/usr/pam_abfp/test.txt","a+");
    snprintf(buffer,sizeof(buffer),"Adding %s",ipadd);
    fputs(buffer,log);
    fclose(log);
    
    return ret;
}

/* check the db if there is a record which exceeds the time limit
 */
void check_db() {
    DB *db;
    DBT key, value;
    DBC *dbc;
    int ret;
    int diff;
    FILE *log;
    char buffer[255];
    
    time_t tnow = time(NULL);
    time_t dbtime;
    db = htdb;

    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&value, 0, sizeof (DBT));

    // go through the databse
    while ((ret = dbc->get(dbc, &key, &value, DB_NEXT)) == 0) {
        // get the time for the record
        dbtime = *(time_t *) value.data;
        diff = difftime(tnow, dbtime);
        // greater than 10minutes
        if (diff > 600) {
            // delete record and paste it into log file
            log = fopen("/usr/pam_abfp/Server_log.txt","a+");
            snprintf(buffer,sizeof(buffer),"Deleting %s\n", (char *)key.data);
            fputs(buffer,log);
            fclose(log);
            dbc->c_del(dbc, 0);
        }
    }
}

/* decrypts the message sent by the client
 */
char * simple_decrypt(char *msg, int key){
    size_t messagelen = strlen(msg);
    size_t keylen = sizeof(key);

    char * encrypted = malloc(messagelen+1);

    int i;
    for(i = 0; i < messagelen; i++) {
        encrypted[i] = msg[i] ^ key;
    }
    encrypted[messagelen] = '\0';

    return encrypted;
}

/* decrypts the message for sending
 */
char * simple_xor(const char *msg, int key){
    size_t messagelen = strlen(msg);
    size_t keylen = sizeof(key);

    char * encrypted = malloc(messagelen+1);

    int i;
    for(i = 0; i < messagelen; i++) {
        encrypted[i] = msg[i] ^ key;
    }
    encrypted[messagelen] = '\0';

    return encrypted;
}

/*
 * 
 */
int main(int argc, char** argv) {
    int listenfd = 0, connfd = 0, c;
    pid_t pid,sid;
    struct sockaddr_in serv_addr, client;
             FILE *log;
                char buffer[100];
    char buff[200];
    int read_size;
    char sendBuff[2000];
    char clientmsg[2000];
    int ret;
    char *ip;
    double p,g,b,f,d,e;
    char * pi;
    char *gi;
    char *di;
    // create socket
    listenfd = socket(AF_INET, SOCK_STREAM, 0);

    memset(&serv_addr, '0', sizeof (serv_addr));
    // set server info
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(5000);
    // bind to address
    bind(listenfd, (struct sockaddr*) &serv_addr, sizeof (serv_addr));
    listen(listenfd, 10);
    // open db
    dbopen("hosttdb.db", "Host-Time", &htdb);

    while (1) {
        // checks for unbans
        check_db();
        c = sizeof (client);
        // accept connection from client
        connfd = accept(listenfd, (struct sockaddr*) &client, (socklen_t*) & c);
    
        // create new thread
        pid = fork();
        if(pid == 0){  
        sid = setsid(); 
        memset(sendBuff, 0, sizeof (sendBuff));
        memset(clientmsg, 0, sizeof (clientmsg));
        // receive message from client
        read_size = recv(connfd, clientmsg, sizeof (clientmsg), 0);
        if (read_size > 0) {
            // diffie-hellman calculation
            srand(time(NULL));
            b = rand()%10+1;
            pi = strtok(clientmsg,",");
            gi = strtok(NULL,",");
            di = strtok(NULL,",");
            p = (double)atoi(pi);
            g = (double)atoi(gi);
            d = (double)atoi(di);
            f = pow(g,b);
            f = fmod(f,p);
            // send to client for calculation
            snprintf(sendBuff,sizeof(sendBuff),"%f",f);
            ret = write(connfd, sendBuff,strlen(sendBuff));
            e = pow(d,b);
            e = fmod(e,p);
            // get encrypted ip
            recv(connfd,clientmsg,sizeof(clientmsg)-1,0);
            if(recv  < 0 ){

                kill(sid,SIGTERM);
                sleep(1);
            }
            // decrypt message
            char * decrypted = simple_decrypt(clientmsg,e);
            // block or check
            if (strstr(decrypted, BLOCK) != NULL) {
                // add to db
                    ip = strtok(decrypted," ");
                    ret = db_add(htdb, ip);
                    if (ret == 0) {
                        snprintf(sendBuff, sizeof (sendBuff), "%s added", ip);
                    } else{
                        snprintf(sendBuff, sizeof (sendBuff), "%s could not be added", ip);
                    }
            }
            // read db to check if it is blocked or not
            else {
                ret = read_db(htdb, decrypted);
                if (ret == 0) {
                    snprintf(sendBuff, sizeof (sendBuff), "%s listed", decrypted);
                } else snprintf(sendBuff, sizeof (sendBuff), "%s not listed", decrypted);
               

            }
            // send answer to client
            ret = write(connfd, sendBuff, strlen(sendBuff));
            // close
            close(connfd);
            kill(sid,SIGTERM);
            sleep(1);
        }
    }
   }
    return (EXIT_SUCCESS);
}
