/* 
 * File:   main.c
 * Author: jurgen
 *
 * Created on June 12, 2013, 10:48 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#define YES "yes"
#define NO "no"

/* returns the minute, e.g 12:35 will return 5
 */
char *my_itoa(int wert, int laenge) {
   char *ret =(char *) malloc(laenge+1 * sizeof(char));
   int i;

   for(i  =0; i < laenge; i++) {
      ret[laenge-i-1] = (wert % 10) + 48;
      wert = wert / 10;
   }
     
   ret[laenge]='\0';
   ret[0] = ret[1];
   ret[1] = '\0';
   return ret;
}



/* writes to the log file
 */
void write_Log(const char *host,const char *isHost) {
    char buffer[1000];
    time_t act_time;
    FILE *log;

    struct stat attr;
    if (stat("/usr/pam_abfp/PAM_ABFP_LOG.txt", &attr) == 0) {
        // delete if size of file is greater
        if (attr.st_size > 100000) {
            remove("/home/jurgen//PAM_ABFP_LOG.txt");
        }
    }

    log = fopen("/usr/pam_abfp/PAM_ABFP_LOG.txt", "a+");

    act_time = time(NULL);
        if (strcmp(isHost, "yes") == 0) {
            snprintf(buffer, sizeof (buffer), "Deleting %s from iptables : %s", host, ctime(&act_time));
            fputs(buffer, log);
        } else {
            snprintf(buffer, sizeof (buffer), "Deleting user %s from blocked group : %s", host, ctime(&act_time));
            fputs(buffer, log);
        }
    
    fclose(log);
}

/* for unblocking the user or host
 */
void command(char *host,char *isHost){
    char block[1000];
    int ret;

    // if status is delete we delete the entries
        if (strcmp(YES, isHost) == 0) {
            // deletes the host from iptables
            //snprintf(block, 1000, "echo %s | sudo -S iptables -D INPUT -s %s -j DROP", pw, host);
            snprintf(block, sizeof (block), "iptables -D INPUT -s %s -j DROP", host);
            ret = system(block);
            write_Log(host, isHost);
            return;
        } else {
            // adds the user to unblock group
            //snprintf(block, 1000, "echo %s | sudo -S usermod -g unblock %s", pw, host); //Syntax error???
            snprintf(block, sizeof (block), "usermod -g unblock %s", host);
            ret = system(block);
            write_Log(host, isHost);
            return;
        }
}

/* deletes the file
 */
void clearFile(const char *fpath){
    FILE *file;
    const char *filep;
    
    filep = fpath;
    
    remove(filep);
    file = fopen(fpath,"a+");
    fclose(file);
    
}

/* removes the user or host from the file
 */
void clearHost(char *isHost,const char *fpath){
    
    FILE *file;
    char buffer[100];
    
    file = fopen(fpath,"a+");
    
    if(file == NULL){
        exit(EXIT_FAILURE);
    }
    
    while(fgets(buffer,sizeof(buffer),file)!= NULL){
        command(buffer,isHost);
    }

    clearFile(fpath);
    fclose(file);
}


/*
 * 
 */
int main(int argc, char** argv) {
    
    time_t tnow;
    int min;
    struct tm *tmnow;
    const char *fpath;
    const char *upath;
    char *smin;
    // get time
    tnow = time(&tnow);
    tmnow = localtime(&tnow);
    smin = my_itoa(tmnow->tm_min,2);    
    min = atoi(smin);
       // which minute we have, unban
    if(min==0){
        fpath = "/usr/pam_abfp/ban/file0";
        upath = "/usr/pam_abfp/ban/u0";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==1){
        fpath = "/usr/pam_abfp/ban/file1";
        upath = "/usr/pam_abfp/ban/u1";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    
    if(min==2){
        fpath = "/usr/pam_abfp/ban/file2";
        upath = "/usr/pam_abfp/ban/u2";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==3){
        fpath = "/usr/pam_abfp/ban/file3";
        upath = "/usr/pam_abfp/ban/u3";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==4){
        fpath = "/usr/pam_abfp/ban/file4";
        upath = "/usr/pam_abfp/ban/u4";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==5){
        fpath = "/usr/pam_abfp/ban/file5";
        upath = "/usr/pam_abfp/ban/u5";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==6){
        fpath = "/usr/pam_abfp/ban/file6";
        upath = "/usr/pam_abfp/ban/u6";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==7){
        fpath = "/usr/pam_abfp/ban/file7";
        upath = "/usr/pam_abfp/ban/u7";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==8){
        fpath = "/usr/pam_abfp/ban/file8";
        upath = "/usr/pam_abfp/ban/u8";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    if(min==9){
        fpath = "/usr/pam_abfp/ban/file9";
        upath = "/usr/pam_abfp/ban/u9";
        clearHost(YES,fpath);
        clearHost(NO,upath);
        
        return (EXIT_SUCCESS);
    }
    
    

    return (EXIT_SUCCESS);
}



