/* 
 * File:   main.h
 * Author: jurgen
 *
 * Created on June 21, 2013, 11:32 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif

    typedef struct {
        DB *utdb;
        DB *ucdb;
        DB *usdb;
        DB *htdb;
        DB *hcdb;
        DB *hsdb;
        const char *host;
        const char *user;
    } info;

#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

