/* 
 * File:   main.c
 * Author: jurgen
 *
 * Created on June 21, 2013, 11:32 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <db.h>
#define YES "yes"
#define NO "no"
#include "main.h"
#include <sys/stat.h>
#include <string.h>


/* creates and opens the database
 */
int dbopen(const char *dbfile, const char *dbname, DB **db) {
    int err;

    // creates the database
    if (err = db_create(db, NULL, 0), 0 != err) {
        printf("Error creating database object");
        return err;
    }

    // opens the database
    if (err = (*db)->open(*db, NULL, dbfile, dbname, DB_BTREE,
            DB_CREATE, 0600), 0 != err) {
        printf("Error opening database");
        return err;
    }

    printf("%s opened\n", dbname);

    return 0;
}

/* prints the database - host-time-db
 * isHost - "yes" print host db, else user db
 */
int print_db(info *info, const char *isHost, const char *db) {
    DB *dbp;
    DBC *cursorp;
    DBT key, data;
    int ret;

    // if isHost is "yes" print host db
    if (strcmp(isHost, "yes") == 0) {
        if (strcmp(db, "time") == 0) {
            dbp = info->htdb;
            goto cursor;
        }
        if (strcmp(db, "count") == 0) {
            dbp = info->hcdb;
            goto cursor;
        }
        if (strcmp(db, "state") == 0) {
            dbp = info->hsdb;
            goto cursor;
        }
    }// else print user db
    else {
        if (strcmp(db, "time") == 0) {
            dbp = info->utdb;
            goto cursor;
        }
        if (strcmp(db, "count") == 0) {
            dbp = info->ucdb;
            goto cursor;
        }
        if (strcmp(db, "state") == 0) {
            dbp = info->usdb;
            goto cursor;
        }
    }

    // Initialize cursor
cursor:    dbp->cursor(dbp, NULL, &cursorp, 0);

    // Initialize our DBTs
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));

    if (strcmp(db, "time") == 0) {
        // go through the database and print each key, value pair
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            printf("Host/User: %s : Time: %s\n", (char *) key.data, ctime(data.data));
            fflush(stdout);
        }
    }
    if (strcmp(db, "count") == 0) {
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            printf("Host/User: %s : Count: %d\n", (char *) key.data, *(int *) data.data);
            fflush(stdout);
        }
    }
    if (strcmp(db, "state") == 0) {
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            printf("Host/User: %s : State: %d\n", (char *) key.data, *(int *) data.data);
            fflush(stdout);
        }
    }
    cursorp->c_close(cursorp);
}

/*
 * 
 */
int main(int argc, char** argv) {
    info *info;
    DB *usdb;
    DB *ucdb;
    DB *hcdb;
    DB *hsdb;
    DB *utdb;
    DB *htdb;
    int err;
    
    info = malloc(sizeof (info));
      
    memset(info, 0, sizeof (info));
    
    err = dbopen("/usr/pam_block/db/usertdb.db", "User-Time", &utdb);
    info->utdb=utdb;

    err = dbopen("/usr/pam_block/db/hosttdb.db", "Host-Time", &htdb);
    info->htdb=htdb;

    err = dbopen("/usr/pam_block/db/hostcdb.db","Host-Count", &hcdb);
    info->hcdb=hcdb;

    err = dbopen("/usr/pam_block/db/usercdb.db","User-Count", &ucdb);
    info->ucdb=ucdb;

    err = dbopen("/usr/pam_block/db/usersdb.db","User-State",&usdb);
    info->usdb=usdb;

    err = dbopen("/usr/pam_block/db/hostsdb.db","Host-State",&hsdb);
    info->hsdb=hsdb;
    
    print_db(info,YES,"time");
    print_db(info,YES,"count");
    print_db(info,YES,"state");    
    print_db(info,NO,"time");
    print_db(info,NO,"count");
    print_db(info,NO,"state");
    
    //check_unbans(info,YES);
    //check_unbans(info,NO);
    
    return (EXIT_SUCCESS);
}

