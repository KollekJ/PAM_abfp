/* 
 * File:   ssh_block.h
 * Author: jurgen
 *
 * Created on April 3, 2013, 11:30 AM
 */

#ifndef MAIN_H
#define	MAIN_H
#define MODULE_NAME "pam_abfp"
#define DATA_NAME   MODULE_NAME
#define _GNU_SOURCE

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <db.h>
#include <sys/types.h>
#include <security/pam_appl.h>
#include <security/pam_modules.h>
#include <security/_pam_types.h>
#include <shadow.h>
#include <sys/stat.h>
#include <GeoIP.h>
#include <GeoIP.h>
#include <resolv.h>
#include <math.h>
#include <crypt.h>

#define YES "yes"
#define NO "no"
#define C_SIZE 
#define NOT "not"
#define CRY "pam_abfp"
#define ADDE "added"

typedef enum { 
    USER,
    HOST,
    BLOCKED,
    CLEAR
} state_enum;

/* stores information, about db and user
 */
typedef struct{
    /* Session handle */
    pam_handle_t    *pamh;
    
    char *host;
    char *user;
    state_enum subject;
    state_enum state;
    char *country;
    DB *utdb;
    DB *ucdb;
    DB *usdb;
    DB *htdb;
    DB *hcdb;
    DB *hsdb;
    DB *list;
    DB *time;
    DB_ENV *dbenv;
    double p,g,mod;
    char *server;
    char *pw;
    char *service;
} info;

typedef struct{
    const char *host;
    int value;
}list_info;

/* functions from common.c
 */
extern int check_attempt(info *info);
extern void clear();

/* functions from db-handle.c
 */
extern int check_hostdb(info *info, const char *isHost);
extern void dbadd(info *info,time_t tm,const char *isHost);
extern int print_db( info *info, const char *isHost, const char *db);
extern int dbopen(const char *dbfile, const char *dbname, DB_ENV *dbenv, DB **db, info *info);
extern void dbupdate(info *info, time_t tm, const char *isHost);
extern void check_unbans(info *info, const char *isHost);

#endif	/* MAIN_H */

