#include "pam_abfp.h"

/* encrypt the password and checks how similiar it is to the right one
 */
int encrypt_pw(info *info,char *pw) {
    const char *salt;
    char *nr;
    const char *hashgen;
    char *hashcopy;
    char *hash;
    char buffer[256];
    char puffer[256];
    int ret = 1;
    struct spwd *encrypt,sp;
    char * crypted;
    char search[] = {'a', 'b', 'e', 'i', 'l', 'o', 's', '4', '8', '3', '1', '1', '0', '5'};
    char repla[] = {'4', '8', '3', '1', '1', '0', '5', 'a', 'b', 'e', 'i', 'l', 'o', 's'};
    int i = 0;
    int j = 0;
    struct crypt_data data;
    data.initialized = 0;
  char pwdbuffer[500];
  // get the crypted pw for user
  getspnam_r(info->user,&sp,pwdbuffer,sizeof(pwdbuffer),&encrypt);
    
    if (encrypt != NULL) {
        
        hashcopy = strdup(encrypt->sp_pwdp);
        hash = strdup(encrypt->sp_pwdp);
        nr = strtok(hashcopy, "$");
        salt = strtok(NULL, "$");
        hashgen = strtok(NULL, "$");
        // create salt and id
        strcat(puffer, "$");
        strcat(puffer, nr);
        strcat(puffer, "$");
        strcat(puffer, salt);
        strcat(puffer, "$");
        data.initialized = 0;

        // get the used password for login
        strncpy(buffer,info->pw,sizeof(buffer)-1);
        if (buffer != NULL) {
            // replace characters from the used password with common replacements
            for (i; i < strlen(buffer); i++) {
                for (j; j<sizeof (search); j++) {
                    if (buffer[i] == search[j]) {
                        buffer[i] = repla[j];
                        // crypt the password used
                        crypted = crypt_r(buffer, puffer, &data);
                        // compare if they are similiar break
                        if (strcmp(crypted, hash) == 0) {
                            ret = 0;
                            break;
                        }
                        buffer[i] = search[j];
                    }
                }
                j = 0;
                if(ret == 0){
                    break;
                }
            }
        }

        if (ret == 0) {
            return 2;
        }
    } else return 1;
}