
#include <string.h>


#include <stdio.h>

#include "pam_abfp.h"

/* create key for db
 */
void make_key(DBT *dbt, const char *key) {
    memset(dbt, 0, sizeof (*dbt));
    dbt->data = (void *) key;
    dbt->size = strlen(key) + 1;
    dbt->ulen = dbt->size + 1;
}

/* get time from time db
 */
time_t dbgettime(info *info, const char *isHost) {
    DB *db;
    DBC *dbc;
    DBT key, data;
    int err;
    const char *kv;
    time_t time;
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->htdb;
        kv = info->host;
    }
    // user case
    else {
        db = info->utdb;
        kv = info->user;
    }

    // create cursor
    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));

    // host case
    if (strcmp(isHost, YES) == 0) {
        // go through db
        while ((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
            // if we have found the right one
            if (strcmp(info->host, (char *) key.data) == 0) {
                // get time
                time = *(time_t *) data.data;
                return time;
            }
        }
    }
    // user case
    if (strcmp(isHost, NO) == 0) {
        // go through db
        while ((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
            // right user found
            if (strcmp(info->user, (char *) key.data) == 0) {
                // get time
                time = *(time_t *) data.data;
                return time;
            }
        }
    }
    return time;
}

/* Grow the buffer of a DBT if necessary
 */
int grow_buffer(DBT *dbt, u_int32_t minsize) {
   if (dbt->ulen < minsize) {
        void *nd = NULL;
        nd = realloc(dbt->data, minsize);
        if(nd == NULL){
            return -1;
        }
        dbt->data = nd;
        dbt->ulen = minsize;
    }
    return 0;
}

/* gets the value of a key
 */
int dbget(DB *db, DBT *key, DBT *dbtdata) {
    int err;

    // sets memory
    memset(dbtdata, 0, sizeof (*dbtdata));
    dbtdata->flags = DB_DBT_USERMEM;

    // reads from the db
    err = db->get(db, NULL, key, dbtdata, 0);

    // if called with DB_DBT_USERMEM, grow buffer
    if (DB_BUFFER_SMALL == err) {
        if (err = grow_buffer(dbtdata, dbtdata->size), 0 != err) {
            return err;
        }
        dbtdata->size = 0;
        // try again, now buffer should be big enough
        err = db->get(db, NULL, key, dbtdata, 0);
    }

    // if not found return
    if (0 != err && DB_NOTFOUND != err) {
        return err;
    }
    // if db not found return and set size to zero
    if (DB_NOTFOUND == err) {
        dbtdata->size = 0;
    }
    // else return
    return err;
}

/* opens the given db
 */
int dbopen(const char *dbfile, const char *dbname, DB_ENV *dbenv, DB **db, info * info) {
    int err;
    *db = NULL;
    DB *dbhandle;
    // create db handle
    if (err = db_create(&dbhandle, dbenv, 0), 0 != err) {
        return err;
    }
    // open db
    if (err = dbhandle->open(dbhandle, NULL, dbfile, dbname, DB_BTREE, DB_CREATE, 0600), 0 != err) {
        return err;
    }
    // checks which db we have opened and sets it in our structure
    if(dbhandle != NULL){
        if(strcmp(dbname,"Host-Count")==0){
            info->hcdb=dbhandle;
            *db = dbhandle;
        }
        if(strcmp(dbname,"Host-Time")==0){
            info->htdb=dbhandle;
            *db = dbhandle;
        }
        if(strcmp(dbname,"User-Time")==0){
            info->utdb=dbhandle;
            *db = dbhandle;
        }
        if(strcmp(dbname,"User-Count")==0){
            info->ucdb=dbhandle;
            *db = dbhandle;
        }
        if(strcmp(dbname,"User-State")==0){
            info->usdb=dbhandle;
            *db = dbhandle;
        }
        if(strcmp(dbname,"Host-State")==0){
            info->hsdb=dbhandle;
            *db = dbhandle;
        }
        if(strcmp(dbname,"List-DB")==0){
            info->list=dbhandle;
            *db = dbhandle;
        }
        if(strcmp(dbname,"Old-Time")==0){
            info->time=dbhandle;
            *db = dbhandle;
        }        
    }
    return 0;
} 

/* removes the count for a user or host
 */
void db_removecount(info *info, const char *Host, const char *isHost) {
    DB *db;
    DBC *dbc;
    DBT key, data;
    int err;
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->hcdb;
    } 
    // user case 
    else db = info->ucdb;

    // create cursor
    err = db->cursor(db, NULL, &dbc, 0);
    
    if(err != 0){
        return;
    }
    
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    // host case
    if (strcmp(isHost, YES) == 0) {
        // get right host
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // if found
            if (strcmp(Host, (char *) key.data) == 0) {
                // delete record
                if (dbc->c_del(dbc, 0) == 0) {
                    dbc->close(dbc);
                    return;
                } else printf("cannot delete host");
            }
        }
    }
    // user case
    else {
        // get right user
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // if found
            if (strcmp(Host, (char *) key.data) == 0) {
                // delete record
                if (dbc->c_del(dbc, 0) == 0) {
                    dbc->close(dbc);
                    return;
                } else printf("cannot delete user");
            }
        }
    }
}

/* removes user or host from db
 */
void db_removetime(info *info, const char *Host, const char *isHost) {
    DB *db;
    DBC *dbc;
    DBT key, data;
    int err;
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->htdb;
    }
    // user case
    else db = info->utdb;

    // create cursor
    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    // host case
    if (strcmp(isHost, YES) == 0) {
        // find right one
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // delete record
            if (strcmp(Host, (char *) key.data) == 0) {
                if (dbc->c_del(dbc, 0) == 0) {
                    dbc->close(dbc);
                    return;
                } else printf("cannot delete host");
            }
        }
    }
    // user case
    else {
        // find right one
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // delete record
            if (strcmp(Host, (char *) key.data) == 0) {
                if (dbc->c_del(dbc, 0) == 0) {
                    dbc->close(dbc);
                    return;
                } else printf("cannot delete user");
            }
        }
    }

}

/* removes the state for user or host
 */
void db_removestate(info *info, const char *Host, const char *isHost) {
    DB *db;
    DBC *dbc;
    DBT key, data;
    int err;
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->hsdb;
    } 
    // user case
    else db = info->usdb;
    // create cursor
    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    // host case
    if (strcmp(isHost, YES) == 0) {
        // go through db
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // right one found
            if (strcmp(Host, (char *) key.data) == 0) {
                // delete record
                if (dbc->c_del(dbc, 0) == 0) {
                    dbc->close(dbc);
                    return;
                } else printf("cannot delete host");
            }
        }
    }
    // user case
    else {
        // go through db
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // found right one
            if (strcmp(Host, (char *) key.data) == 0) {
                // delete record
                if (dbc->c_del(dbc, 0) == 0) {
                    dbc->close(dbc);
                    return;
                } else printf("cannot delete user");
            }
        }
    }

}

/* checks if we have users or hosts to unban
 */
void check_unbans(info *info, const char *isHost) {
    int ret, diff;
    time_t tban;
    time_t tnow;
    DB *db;
    DBC *dbc;
    DBT key, data;
    const char *Host;
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->htdb;
    }
    // user case
    else db = info->utdb;
    // create cursor
    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));

    // get actual time
    tnow = time(NULL);
    // go through db
    while ((ret = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
        // get time
        tban = *(time_t *) data.data;
        Host = (char *) key.data;
        diff = difftime(tnow, tban);
        // if time is greater than 10 minutes delete
        if (diff >= 600) {
            db_removestate(info, Host, isHost);
            db_removetime(info, Host, isHost);
            db_removecount(info, Host, isHost);
        }
    }
    dbc->close(dbc);
}

/* checks the database if host or user is already stored
 */
int check_hostdb(info *info, const char *isHost) {
    DB *db;
    DBC *cursorp;
    DBT key, data;
    int ret = 0;
    int err;

    // if isHost is "yes" print host db
    if (strcmp(isHost, "yes") == 0) {
        db = info->hsdb;
    }// else print user db
    else db = info->usdb;

    // create cursor
    db->cursor(db, NULL, &cursorp, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));


    // host case
    if (strcmp(isHost, YES) == 0) {
        // go through 
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            // if host found return
            if (strcmp((char *) key.data, info->host) == 0) {
                if (*(int *) data.data == 1) { 
                    return -1;
                } else {

                    return 1;
                }
            }
        }
    }
    // user case
    else {
        // go through db
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            // found right user return
            if (strcmp((char *) key.data, info->user) == 0) {
                if (*(int *) data.data == 1) { 
                    return -1;
                } else {

                    return 1;
                }
            }
        }
    }

    return 0;
}

/* updates the state for a user or host
 */
void dbupdatestate(info *info,time_t tnow, const char *isHost) {
    DB *db;
    DBT key, data;
    DBC *dbc;
    const char *kv;
    int err = 0;
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->hsdb;
        kv = info->host;
    } 
    // user case
    else {
        db = info->usdb;
        kv = info->user;
    }
    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    // host case
    if (strcmp(isHost, YES) == 0) {
        // go through db
        while ((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
            // find right one
            if (strcmp(info->host, (char *) key.data) == 0) {
                // delete record
                if (dbc->c_del(dbc, 0) == 0) {
                    // add to db again with changed state
                    dbstateadd(info, isHost, 1);
                    //  add to iptables
                    command(info->host, "add", isHost,tnow);
                }
            }
        }
    }
    // user case
    if (strcmp(isHost, NO) == 0) {
        // go through db
        while ((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
            // find the right one
            if (strcmp(info->user, (char *) key.data) == 0) {
                // delete record
                if (dbc->c_del(dbc, 0) == 0) {
                    // add again with changed state
                    dbstateadd(info, isHost, 1);
                    // move user to another group
                    command(info->user, "add", isHost,tnow);
                }
            }
        }
    }
}

/* gets the value for a host
 */
int getvalue(info *info){
    DB *db;
    DBT key,data;
    const char *kv;
    int ret;
    // get the country for a host
    char * returned = (char *) geo_ip(info->host);
    
    db = info->list;
    
    if(returned != NULL){    
        kv = returned;
    }
    else{
        return 3;
    }
    
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    make_key(&key, kv);
    // get the value for a country
    ret = dbget(db, &key, &data);
    if(ret != 0){
        return 3;
    }
    return *(int *)data.data;    
}

/* updates the count for a host or user
 */
void dbupdatecount(info *info, const char *isHost) {
    DB *db;
    DBT key, data;
    DBC *dbc;
    const char *kv;
    int err = 0;
    int count = 0;
    time_t dbtime;
    time_t tnow;
    int value=0;
    int diff;
    FILE *conf;
    char buffer[100];
    char *user;
    char *ucount;
    int uc;
    int usercount=1;

   // host case or user case
    if (strcmp(isHost, YES) == 0) {
        db = info->hcdb;
        kv = info->host;
    } else {
        db = info->ucdb;
        kv = info->user;
    }

    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    // host case
    if (strcmp(isHost, YES) == 0) {
        // go through db
        while ((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
            // find right one
            if (strcmp(info->host, (char *) key.data) == 0) {
                // get count
                count = *(int*) data.data;
                // delet record and add with new count
                if (dbc->c_del(dbc, 0) == 0) {
                    count = dbcountadd(info, isHost, count,0);
                    dbc->close(dbc);
                }
            }
        }
    }
    // user case
    if (strcmp(isHost, NO) == 0) {
        // go through db
        while ((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
            // find right one
            if (strcmp(info->user, (char *) key.data) == 0) {
                // get count from db
                count = *(int *) data.data;
                // get user count from user config
                conf = fopen("/usr/pam_abfp/user.conf","a+");
                if(conf != NULL){
                    // go through file
                    while(fgets(buffer,sizeof(buffer),conf)!=NULL){
                        // ignore comments
                        if(strncmp(buffer,"#",1)!=0){
                            // get user and count
                            user = strtok(buffer,"=");
                            ucount = strtok(NULL,"\n");
                            uc = atoi(ucount);
                            // if we found the right one set update count
                            if(strcmp(user,info->user)==0){
                                usercount = uc;
                                break;
                            }
                        }
                    }
                    fclose(conf);
                }
                // calculate count
                count = count + usercount;
                // delete record
                if (dbc->c_del(dbc, 0) == 0) {
                    dbcountadd(info, isHost, count,0);
                }
            }
        }
    }
    // host case
    if(strcmp(isHost,YES)==0){
        // get value
        value = getvalue(info);
        if(value == 1){
            // exceeds threshold check if time exceeds
            if(count >= 90){
                tnow = time(NULL);
                dbtime = dbgettime(info, isHost);
                diff = difftime(tnow, dbtime);
                if (diff <= 600) {
                        // notify masterserver
                        send_server(info);
                        // change state
                        dbupdatestate(info,tnow, isHost);
                        return;
                }
            }
            else return;
        }
        if (value == 2){ 
            // exceeds threshold check if time exceeds
            if(count >= 140){
                tnow = time(NULL);
                dbtime = dbgettime(info, isHost);
                diff = difftime(tnow, dbtime);
                if (diff <= 600) {
                        // notify masterserver
                        send_server(info);
                        // change state
                        dbupdatestate(info,tnow, isHost);
                        return;
                }
            }
            else return;
            }
        if(value == 3){ 
            // exceeds threshold check if time exceeds
            if(count >= 150){
                tnow = time(NULL);
                dbtime = dbgettime(info, isHost);
                diff = difftime(tnow, dbtime);
                if (diff <= 600) {
                        // notify masterserver
                        send_server(info);
                        // change state
                        dbupdatestate(info,tnow, isHost);
                        return;
                }
            }
            else return;
        }
        if(value == 4){
            //exceeds threshold check if time exceeds
            if(count >= 120 ){
                tnow = time(NULL);
                dbtime = dbgettime(info, isHost);
                diff = difftime(tnow, dbtime);
                if (diff <= 600) {
                        // notfiy masterserver
                        send_server(info);
                        // change state
                        dbupdatestate(info,tnow, isHost);
                        return;
                }
            }
            else return;
        }
        if(value == 5){ 
            // exceeds threshold, check if time exceeds
            if(count >= 50 ){
                tnow = time(NULL);
                dbtime = dbgettime(info, isHost);
                diff = difftime(tnow, dbtime);
                if (diff <= 600) {
                        // notify masterserver
                        send_server(info);
                        // change state
                        dbupdatestate(info,tnow, isHost);
                        return;
                }
            }
            else return;
        }
    }
    // user case
    else{
        // exceeds threshold, check if time exceeds
        if (count >= 9) {
            tnow = time(NULL);
            dbtime = dbgettime(info, isHost);
            diff = difftime(tnow, dbtime);
            if (diff <= 600) {
                // change state
                dbupdatestate(info,tnow, isHost);
                return;
        }
    }
        else return;
    }

}

/* store the old failed login time into db
 */
void oldtime(info *info, const char *isHost){
    DB *db;
    DB *time;
    const char *kv;
    DBT key,data;
    DBT k,d;
    int err;
    
    time = info->time;
    // host case or user case
    if(strcmp(YES,isHost)==0){
        db = info->htdb;
        kv = info->host;
    }
    else{
        db = info->utdb;
        kv = info->user;
    }
    
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    memset(&k, 0, sizeof (DBT));
    memset(&d, 0, sizeof (DBT));

    make_key(&key, kv);
    // get record from db from host or user time db
    err = dbget(db, &key, &data);
    
    if(err == 0){
        make_key(&k,kv);
        // get record from timeold db
        err = dbget(time,&k,&d);
        if(err == 0){
            // delete record
            if(time->del(time,NULL,&k,0)==0){
                // add with new time
                if(time->put(time,NULL,&k,&data,DB_NOOVERWRITE) == 0){
                    return;
                }
            }
        }
        // not in oldtime db, so we add
        else{
            if(time->put(time,NULL,&k,&data,DB_NOOVERWRITE) == 0){
                    return;
                }
    }
    }
    return;
}

/* updates the time for a host or user
 */
void dbupdatetime(info *info, time_t tnow, const char *isHost) {
    DB *db;
    DBC *dbc;
    DBT key, data;
    int err;
    const char *kv;
    // host case or user
    if (strcmp(isHost, YES) == 0) {
        db = info->htdb;
        kv = info->host;
    } else {
        db = info->utdb;
        kv = info->user;
    }

    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
        
    make_key(&key, kv);
    // retrieve record from db
    err = dbget(db, &key, &data);
    
    if(err == 0){
        // store old time
        oldtime(info, isHost);
        // delete time
        if(db->del(db,NULL,&key,0)==0){
            // add new time
            dbtimeadd(info, tnow, isHost);
        }
    }
}

/* prints the database - host-time-db
 * isHost - "yes" print host db, else user db
 */
int print_db(info *info, const char *isHost, const char *db) {
    DB *dbp;
    DBC *cursorp;
    DBT key, data;
    int ret;

    // if isHost is "yes" print host db
    if (strcmp(isHost, "yes") == 0) {
        if (strcmp(db, "time") == 0) {
            dbp = info->htdb;
        }
        if (strcmp(db, "count") == 0) {
            dbp = info->hcdb;
        }
        if (strcmp(db, "state") == 0) {
            dbp = info->hsdb;
        }
        if(strcmp(db,"list")==0){
            dbp = info->list;
        }
    }// else print user db
    else {
        if (strcmp(db, "time") == 0) {
            dbp = info->utdb;
        }
        if (strcmp(db, "count") == 0) {
            dbp = info->ucdb;
        }
        if (strcmp(db, "state") == 0) {
            dbp = info->usdb;
        }
        if(strcmp(db,"list")==0){
            dbp = info->list;
        }
    }

    // Initialize cursor
    dbp->cursor(dbp, NULL, &cursorp, 0);

    // Initialize our DBTs
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));

    if (strcmp(db, "time") == 0) {
        // go through the database and print each key, value pair
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            //log = fopen("/var/log/DEBU_LOG-test.txt", "a+");
            //snprintf(buffer, sizeof (buffer), "Host/User: %s : Time: %s", (char *) key.data, ctime(data.data));
            //fputs(buffer, log);
            //fclose(log);
            printf("Host/User: %s : Time: %s\n", (char *) key.data, ctime(data.data));
        }
        // close cursor

    }
    if (strcmp(db, "count") == 0) {
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            //log = fopen("/var/log/DEBU_LOG-test.txt", "a+");
            //snprintf(buffer, sizeof (buffer), "Host/User: %s : Count: %d\n", (char *) key.data, *(int *) data.data);
            //fputs(buffer, log);
            //fclose(log);
            printf("Host/User: %s : Count: %d\n", (char *) key.data, *(int *) data.data);
        }
    }
    if (strcmp(db, "state") == 0) {
        while ((ret = cursorp->get(cursorp, &key, &data, DB_NEXT)) == 0) {
            //log = fopen("/var/log/DEBU_LOG-test.txt", "a+");
            //snprintf(buffer, sizeof (buffer), "Host/User: %s : State: %d\n", (char *) key.data, *(int *) data.data);
            //fputs(buffer, log);
            //fclose(log);
            printf("Host/User: %s : State: %d\n", (char *) key.data, *(int *) data.data);
        }
    }
    if(strcasecmp(db,"list")==0){
        while((ret = cursorp->get(cursorp, &key, &data, DB_NEXT))==0){
            //log = fopen("/var/log/DEBU_LOG-test.txt", "a+");
            //snprintf(buffer, sizeof (buffer), "Host/User: %s : Time: %s", (char *) key.data, *(int *)data.data);
            //fputs(buffer, log);
            //fclose(log);
            printf("Country:%s State:%d\n",(char *)key.data,*(int *)data.data);
        }
    }

    cursorp->c_close(cursorp);
}

/* adds the user or host to the databases
 */
void dbadd(info *info, time_t tm, const char *isHost) {
    int value;
    time_t tnow;
    int diff;
    time_t dbtime;
    // add to state and time db
    dbstateadd(info, isHost, 0);
    dbtimeadd(info, tm, isHost);
    // host case
    if(strcmp(isHost,YES)==0){
        // add count
        dbcountadd(info, isHost, 0,1);
        // get value for country
        value = getvalue(info);
        // if it is 5 block it
        if(value == 5){
            tnow = time(NULL);
            dbtime = dbgettime(info, isHost);
            diff = difftime(tnow, dbtime);
            if (diff <= 600) {
                // notify masterserver
                send_server(info);
                // change state
                dbupdatestate(info,tnow, isHost);
                return;
            }
        }else return;
    }
    // add count for user
    else dbcountadd(info, isHost, 1,1);
    
    return;

}

/* adds state for user or host
 */
int dbstateadd(info *info, const char *isHost, int *state) {
    DB *db;
    DBT key, data;

    const char *kv;
    int err = 0;
    // host or user case
    if (strcmp(isHost, YES) == 0) {
        db = info->hsdb;
        kv = info->host;
    } else {
        db = info->usdb;
        kv = info->user;
    }
    
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));

    make_key(&key, kv);
    // get record from db
    err = dbget(db, &key, &data);
    
    if (0 != err && DB_NOTFOUND != err) {
        return err;
    }
    // if db is not found return
    if (DB_NOTFOUND == err) {
        data.size = 0;
    }
    // grow buffer if it's too small
    if (err = grow_buffer(&data, data.size + sizeof (int)), 0 != err) {
        return err;
    }

    // copy to another memory to have enough space
    memcpy((char *) data.data + data.size, &state, sizeof (int));
    data.size += sizeof (int);
    // put it into our db
    err = db->put(db, NULL, &key, &data, 0);

    return err;
}

/* add time for user or host into db
 */
int dbtimeadd(info *info, time_t tnow, const char *isHost) {
    DB *db;
    DBT key, data;
    int err = 0;
    const char *kv;
    // host or user case
    if (strcmp(isHost, YES) == 0) {
        db = info->htdb;
        kv = info->host;
    } else {
        db = info->utdb;
        kv = info->user;
    }

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));

    make_key(&key, kv);
    // get record from db
    err = dbget(db, &key, &data);
    if(err == 0){
        return err;
    }
    if (0 != err && DB_NOTFOUND != err) {
        return err;
    }
    // if db is not found return
    if (DB_NOTFOUND == err) {
        data.size = 0;
    }
    // grow buffer if it's too small
    if (err = grow_buffer(&data, data.size + sizeof (tnow)), 0 != err) {
        return err;
    }

    // copy to another memory to have enough space
    memcpy((char *) data.data + data.size, &tnow, sizeof (tnow));
    data.size += sizeof (tnow);
    // put into db
    err = db->put(db, NULL, &key, &data, DB_NOOVERWRITE);

    return err;
}

/* calculate the count for user or host
 */
int calc_count(info *info,int count,const char *isHost,int firstc){
    DB *db;
    DBC *dbc;
    DBT key,data;
    int err = 0;
    const char *kv;
    int value = 3;
    int c = count;
    FILE *conf;
    char buffer[100];
    char *user;
    char *ucount;
    int uc=0;
    // user case
    if(strcmp(isHost,NO)==0){
        // first time we add, we have already the counter
        if(firstc == 0){
            return count;
        }
        // else get it from config
        conf = fopen("/usr/pam_abfp/user.conf","a+");
        if(conf != NULL){
            // try to find the right one
        while(fgets(buffer,sizeof(buffer),conf)!= NULL){
            // ignore comments
            if(strncmp(buffer,"#",1)!=0){
                user = strtok(buffer,"=");
                ucount = strtok(NULL,"\n");
                uc = atoi(ucount);
                // get counter for user
                if(strcmp(user,info->user)==0){
                    uc = uc;
                    return uc;
                }
            }
        }
        fclose(conf);
        }
        return c;
    }
    // host case
    else{
    char *returned = malloc(sizeof(char)*200);
    memset(returned,'\0',sizeof(char));    
    // get country for host
    returned = (char *) geo_ip(info->host);
    
    db = info->list;
    kv = info->host;
    
    
    db->cursor(db, NULL, &dbc, 0);

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    
    if(returned != NULL){
        // get the value for the country
    while ((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0) {
        if(strncmp(returned,(char *)key.data,2)==0){
            value = *(int *)data.data;
            break;
        }
    }
    //dbc->c_close(dbc);
    }
    // new host counter
    c = 10 * value + c;
    
    return c;
    }
}

/* add the user or host with a count into the db
 */
int dbcountadd(info *info, const char *isHost, int count,int firstc) {
    DB *db;
    DBT key, data;
    int err = 0;
    const char *kv;
    int c;
// host or user
    if (strcmp(isHost, YES) == 0) {
        db = info->hcdb;
        kv = info->host;
    } else {
        db = info->ucdb;
        kv = info->user;
    }
// caluclate the count
    c = calc_count(info, count,isHost, firstc);

    
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));

    make_key(&key, kv);
    // get record from db
    err = dbget(db, &key, &data);
    if (0 != err && DB_NOTFOUND != err) {
        return err;
    }
    // if db is not found return
    if (DB_NOTFOUND == err) {
        data.size = 0;
    }
    // grow buffer if it's too small
    if (err = grow_buffer(&data, data.size + sizeof (c)), 0 != err) {
        return err;
    }
    // copy to another memory to have enough space
    memcpy((char *) data.data + data.size, &c, sizeof (c));
    data.size += sizeof (c);
    // put into db
    err = db->put(db, NULL, &key, &data, 0);
    if(err != 0){
        return err;
    }
    return c;
}

/* this function is used to get the minute, e.g 12:23 it will retrieve 3
 */
char *my_itoa(int wert, int laenge) {
   char *ret =(char *) malloc(laenge+1 * sizeof(char));
   int i;

   for(i  =0; i < laenge; i++) {
      ret[laenge-i-1] = (wert % 10) + 48;
      wert = wert / 10;
   }
     
   ret[laenge]='\0';
   ret[0] = ret[1];
   ret[1] = '\0';
   return ret;
}

/* adds host or user to the file for the testdb programm
 */
void addHost(const char *Host,const char *fpath){
    FILE *file;
    char buffer[100];
    
    file = fopen(fpath,"a+");
    if(file != NULL){
        snprintf(buffer, sizeof (buffer), "%s", Host);
        fputs(buffer,file);
        fclose(file);
    }    
}

/* adds the host or user to the right file
 */
void addtoFile(const char *isHost,const char *Host,time_t tnow){
    int min;
    struct tm *tmnow;
    const char *fpath;
    const char *upath;
    char *smin;
    // get actual time
    tmnow = localtime(&tnow);
    // get min
    smin = my_itoa(tmnow->tm_min,2);    
    min = atoi(smin);
       // paste it into the right file
    if(min==0){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file0";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u0";
            addHost(Host,upath);
            return;            
        }
    }
    if(min==1){
        if(strcasecmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file1";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u1";
            addHost(Host,upath);
            return;
        }
    }
    
    if(min==2){
        if(strcasecmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file2";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u2";
            addHost(Host,upath);
            return;
        }
        
    }
    if(min==3){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file3";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u3";
            addHost(Host,upath);
            return;            
        }
        
        
    }
    if(min==4){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file4";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u4";
            addHost(Host,upath);
            return;            
        }
    }
    if(min==5){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file5";
            addHost(Host,fpath);
            return;            
        }
        else{
            upath = "/usr/pam_abfp/ban/u5";
            addHost(Host,upath);
            return;            
        }
    }
    if(min==6){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file6";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u6";
            addHost(Host,upath);
            return;
        }
    }
    if(min==7){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file7";
            addHost(Host,fpath);
            return;            
        }
        else{
            upath = "/usr/pam_abfp/ban/u7";
            addHost(Host,upath);
            return;
        }
    }
    if(min==8){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file8";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u8";
            addHost(Host,upath);
            return;
        }
    }
    if(min==9){
        if(strcmp(isHost,YES)==0){
            fpath = "/usr/pam_abfp/ban/file9";
            addHost(Host,fpath);
            return;
        }
        else{
            upath = "/usr/pam_abfp/ban/u9";
            addHost(Host,upath);
            return;            
        }
    }
}

/* this executes system commands
 * isHost - "yes" we record to iptables, else we move to user to another group
 * status - "delete" we delete from db, else we record
 */
int command(const char *host, const char *status, const char *isHost,time_t tnow) {
    char block[1000];
    int ret;

    // if status is delete we delete the entries
    if (strcmp(status, "delete") == 0) {
        if (strcmp("yes", isHost) == 0) {
            // deletes the host from iptables
            //snprintf(block, 1000, "echo %s | sudo -S iptables -D INPUT -s %s -j DROP", pw, host);
            snprintf(block, sizeof (block), "iptables -D INPUT -s %s -j DROP", host);
            ret = system(block);
            write_Log(host, status, isHost);
            return ret;
        } else {
            // adds the user to unblock group
            //snprintf(block, 1000, "echo %s | sudo -S usermod -g unblock %s", pw, host); //Syntax error???
            snprintf(block, sizeof (block), "usermod -g unblock %s", host);
            ret = system(block);
            write_Log(host, status, isHost);
            return ret;
        }
    }// if status is not delete, we add
    else {
        if (strcmp("yes", isHost) == 0) {
            // adds host to iptables
            //snprintf(block, 1000, "echo %s | sudo -S iptables -A INPUT -s %s -j DROP", pw, host);
            snprintf(block, sizeof (block), "iptables -A INPUT -s %s -j DROP", host); //richtige anweisung
            ret = system(block);
            addtoFile(YES,host,tnow);
            write_Log(host, status, isHost);
            return ret;
        } else {
            // adds the user to blocked group
            //snprintf(block, 1000, "echo %s | sudo -S usermod -g blocked %s", pw, host);
            snprintf(block, sizeof (block), "usermod -g blocked %s", host);
            ret = system(block);
            addtoFile(NO,host,tnow);
            write_Log(host, status, isHost);
            return ret;
        }
    }
}