/* This file is used for common methods,
 * e.g. getting the actual time
 * also it initializes the host- and userlist
 */

#include <pwd.h>

#include "pam_abfp.h"

/* checks the state for a given user or host, if it is already blocked or not
 */
int check_state(info* info, const char *isHost) {
    DB *db;
    DBT key, data;
    const char *kv;
    int err, ret;
    
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->hsdb;
        kv = info->host;
    }
    // user case
    else {
        db = info->usdb;
        kv = info->user;
    }

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    make_key(&key, kv);
    // retrive the record from the db
    err = dbget(db, &key, &data);
    
    // succesful retrieve
    if (err == 0) {
        // check if it s blocked or not
        if (*(int *) data.data == 1) {
            ret = 1;
        } else ret = 0;
    }
    return ret;
}

/* this function changes the state for a given host or user
 */
void change_state(info *info, const char *isHost) {
    DB *db;
    DBT key, data;
    const char *kv;
    int err;

    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->hsdb;
        kv = info->host;
    }
    // user case
    else {
        db = info->usdb;
        kv = info->user;
    }

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    make_key(&key, kv);
    // retrieve record
    err = dbget(db, &key, &data);

    // if found...
    if (err == 0) {
        // ... delete record
        if (db->del(db, NULL, &key, 0) == 0) {
            // and add it with new state
            dbstateadd(info, isHost, 0);
        }
    }
}

/* this function changes the last login time for a host or user
 */
void decreasetime(info *info, const char *isHost) {
    DB *db;
    DB *oldtime;
    DBT key, data, k, d;
    const char *kv;
    int err;

    // set db
    oldtime = info->time;
    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->htdb;
        kv = info->host;
    }
    // user case
    else {
        db = info->utdb;
        kv = info->user;
    }

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    memset(&k, 0, sizeof (DBT));
    memset(&d, 0, sizeof (DBT));
    make_key(&key, kv);
    // retrieve record before last time
    err = dbget(oldtime, &key, &data);
    // if succesful
    if (err == 0) {
        make_key(&k, kv);
        err = dbget(db, &k, &d);
        // retrieve last time
        if (err == 0) {
            // delete time
            if (db->del(db, NULL, &k, 0) == 0) {
                // add last last login time
                db->put(db, NULL, &k, &data, DB_NOOVERWRITE);
            }
        }
    }
}

/* decreases the count for a user or host
 */
void decreasecount(info *info, const char *isHost) {
    DB *db;
    DB *list;
    DBT key, data;
    const char *kv;
    int err;
    int value = 3;
    int c = 1;
    FILE *conf;
    char buffer[100];
    char *user;
    char *ucount;
    int uc;
    int usercount = 1;

    // host case
    if (strcmp(isHost, NO) == 0) {
        db = info->ucdb;
        kv = info->user;
    } 
    // user case
    else {
        db = info->hcdb;
        kv = info->host;
    }

    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    make_key(&key, kv);
    // retrieve record
    err = dbget(db, &key, &data);
    // if found
    if (err == 0) {
        c = *(int *) data.data;
        // host case
        if (strcmp(isHost, YES) == 0) {
            // get the value for the country
            value = getvalue(info);
            // calculate teh decrease
            c = c - (10 * value);
            // delete record
            if (db->del(db, NULL, &key, 0) == 0) {
                // set new count and store it to db
                data.data = &c;
                data.size = sizeof (c);
                db->put(db, NULL, &key, &data, DB_NOOVERWRITE);
            }
        } 
        // user case
        else {
            // get actual count
            c = *(int *) data.data;
            // open user config with value
            conf = fopen("/usr/pam_abfp/user.conf", "a+");
            // open successful
            if (conf != NULL) {
                rewind(conf);
                // go through the file
                while (fgets(buffer, sizeof (buffer), conf) != NULL) {
                    // ignore comments
                    if (strncmp(buffer, "#", 1) != 0) {
                        // get user
                        user = strtok(buffer, "=");
                        // get value
                        ucount = strtok(NULL, "\n");
                        uc = atoi(ucount);
                        // right user?
                        if (strcmp(user, info->user) == 0) {
                            // set decrease count
                            usercount = uc;
                            break;
                        }
                    }
                }
                fclose(conf);
            }
            // decrease count
            c = c - usercount;
            // delete record
            if (db->del(db, NULL, &key, 0) == 0) {
                // set new count and add to db
                data.data = &c;
                data.size = sizeof (c);
                db->put(db, NULL, &key, &data, DB_NOOVERWRITE);
            }
        }

    }
}

/* checks the count for a given host or user
 */
int check_count(info * info, const char *isHost) {
    DB *db;
    DBT key, data;
    DBC *dbc;
    const char *kv;
    int err, value;
    time_t tnow = time(NULL);
    int count;

    // host case
    if (strcmp(isHost, YES) == 0) {
        db = info->hcdb;
        kv = info->host;
    } 
    // user case
    else {
        db = info->ucdb;
        kv = info->user;
    }
    memset(&key, 0, sizeof (DBT));
    memset(&data, 0, sizeof (DBT));
    make_key(&key, kv);
    // retrieve record from db
    err = dbget(db, &key, &data);

    if (db == NULL) {
        return -1;
    }
    // open cursor
    db->cursor(db, NULL, &dbc, 0);

    // host case
    if (strcmp(isHost, YES) == 0) {
        // go through db and find right entry
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // if found break
            if (strcmp(info->host, (char *) key.data) == 0) {
                err = 10;
                break;
            }
        }
    } 
    // user case
    else {
        // go through and find right entry
        while (((err = dbc->get(dbc, &key, &data, DB_NEXT)) == 0)) {
            // if found break
            if (strcmp(info->user, (char *) key.data) == 0) {
                err = 10;
                break;
            }
        }
    }
    // entry found
    if (err == 10) {
        // host case
        if (strcmp(isHost, YES) == 0) {
            // retrieve value for country
            value = getvalue(info);
            // value one country
            if (value == 1) {
                // get count
                count = *(int *) data.data;
                // count exceeds threshold
                if (count >= 90) {
                    // decrease count for host
                    decreasecount(info, isHost);
                    // unblock
                    command(info->host, "delete", isHost, tnow);
                    // change state
                    change_state(info, isHost);
                    // decrease time
                    decreasetime(info, isHost);
                    return 0;
                } else {
                    // decrease count
                    decreasecount(info, isHost);
                    // decrease time
                    decreasetime(info, isHost);
                    return 0;
                }
            }
            // value 2 country
            if (value == 2) {
                // get count
                count = *(int *) data.data;
                // exceeds threshold
                if (count >= 140) {
                    decreasecount(info, isHost);
                    command(info->host, "delete", isHost, tnow);
                    change_state(info, isHost);
                    decreasetime(info, isHost);
                    return 0;
                } else {
                    decreasetime(info, isHost);
                    decreasecount(info, isHost);
                    return 0;
                }
            }
            // value 3 country
            if (value == 3) {
                // get count
                count = *(int *) data.data;
                // exceeds threshold
                if (count >= 150) {
                    decreasecount(info, isHost);
                    command(info->host, "delete", isHost, tnow);
                    change_state(info, isHost);
                    decreasetime(info, isHost);
                    return 0;
                } else {
                    decreasetime(info, isHost);
                    decreasecount(info, isHost);
                    return 0;
                }
            }
            // value 4 country
            if (value == 4) {
                // get count
                count = *(int *) data.data;
                // exceeds threshold
                if (count >= 120) {
                    decreasecount(info, isHost);
                    command(info->host, "delete", isHost, tnow);
                    change_state(info, isHost);
                    decreasetime(info, isHost);
                    return 0;
                } else {
                    decreasetime(info, isHost);
                    decreasecount(info, isHost);
                    return 0;
                }
            }
            // value 5 country
            if (value == 5) {
                // get count
                count = *(int *) data.data;
                // exceed threshold
                if (count >= 50) {
                    decreasecount(info, isHost);
                    command(info->host, "delete", isHost, tnow);
                    change_state(info, isHost);
                    decreasetime(info, isHost);
                    return 0;
                } else {
                    decreasetime(info, isHost);
                    decreasecount(info, isHost);
                    return 0;
                }
            }
        } 
        // user case
        else {
            // get count
            count = *(int *) data.data;
            // exceeds threshold
            if (count >= 9) {
                decreasecount(info, isHost);
                command(info->user, "delete", isHost, tnow);
                change_state(info, isHost);
                decreasetime(info, isHost);
                return 0;
            } else {
                decreasetime(info, isHost);
                decreasecount(info, isHost);
                return 0;
            }
        }
    } else return -1;
}

// retrieve country for a given host
const char * geo_ip(char *ipadd) {
    GeoIP *gi;
    int i;
    const char *ret;
    const char *retr;

    // open the files
    for (i = 0; i < 2; ++i) {
        if (0 == i) {
            /* Read from filesystem, check for updated file */
            gi = GeoIP_open("/usr/pam_abfp/GeoIP-1.5.1/data/GeoIP.dat",
                    GEOIP_STANDARD | GEOIP_CHECK_CACHE);
        } else {
            /* Read from memory, faster but takes up more memory */
            gi = GeoIP_open("/usr/pam_abfp/GeoIP-1.5.1/data/GeoIP.dat", GEOIP_MEMORY_CACHE);
        }

        if (gi == NULL) {
            fprintf(stderr, "Error opening database\n");
            exit(1);
        }
    }

    // retrieve country by ip-address
    ret = GeoIP_country_code_by_addr(gi, ipadd);
    
    // if we couldn't
    if (ret == NULL) {
        // retrieve it by name
        retr = GeoIP_country_code_by_name(gi, ipadd);
        if (retr != NULL) {
            return retr;
        }
    } else {
        return ret;
    }
    return NULL;
}

/* function to decrease time and count
 */
void decrease(info *info, const char *isHost) {
    decreasetime(info, isHost);
    decreasecount(info, isHost);
}

/* this function updates the databases
 */
void dbupdate(info *info, time_t tm, const char *isHost) {

    dbupdatetime(info, tm, isHost);
    dbupdatecount(info, isHost);
}

/* prompt for password, so we can compare it with the right one
 */
int prompt_password(struct pam_conv *pam_convp, char **response, int echo, const char *prompt) {
    struct pam_message mesg;
    const struct pam_message *mesgp = &mesg;
    struct pam_response *resp;
    int errcode = 10;
    // check if we can prompt for password
    if (pam_convp == NULL || pam_convp->conv == NULL || response == NULL) {
        return -1;
    }

    *response = NULL;

    mesg.msg_style = echo ? PAM_PROMPT_ECHO_ON : PAM_PROMPT_ECHO_OFF;
    mesg.msg = prompt;

    // try to retrieve the password
    errcode = (*(pam_convp->conv))(1, &mesgp, &resp, pam_convp->appdata_ptr);
    if (resp != NULL) {
        *response = resp->resp;
        //free(resp); /* but not resp->resp *
    }
    return errcode;
}

/* get the password for a given user
 */
int get_pw(info *info) {

    char * password;

    struct pam_conv * pam_convp = NULL;
    int errorcode;
    struct pam_message mesg;
    const struct pam_message *mesgp = &mesg;
    struct pam_response *resp;
    int errcode = 10;
    // try to get it from pam
    (void) pam_get_item(info->pamh, PAM_AUTHTOK, (const void **) &password);
    // if failed
    if (password == NULL) {
        // get the conversion function
        if ((pam_get_item(info->pamh, PAM_CONV, (const void **) &pam_convp) != PAM_SUCCESS) ||
                pam_convp == NULL || pam_convp->conv == NULL) {
            return -1;
        }
        //errorcode = prompt_password(pam_convp, &password, 0, "Password: ");

        mesg.msg_style = 0 ? PAM_PROMPT_ECHO_ON : PAM_PROMPT_ECHO_OFF;
        mesg.msg = "Password: ";
        // try to retrieve it from conversion
        errcode = (*(pam_convp->conv))(1, &mesgp, &resp, pam_convp->appdata_ptr);
        // succesful
        if (resp != NULL) {
            password = resp->resp;
            //free(resp); /* but not resp->resp *
        }
        if (errorcode != PAM_SUCCESS || password == NULL) {
            return -1;
        }
        if (password[0] == '\0') {
            return -1;
        }
        // store the password for future reference
        (void) pam_set_item(info->pamh, PAM_AUTHTOK, password);
        info->pw = strdup(password);
        return 0;
    } else return 0;
}

/* parse the list.txt file to the list db
 */
void parse_list(info *info) {
    FILE *file;
    char buffer[20] = "";
    char host[30] = "";
    int val;
    int err;

    //file = fopen("list.txt", "a+");
    // open the file
    file = fopen("/usr/pam_abfp/lists/list.txt", "a+");
    if (file == NULL) {
        return;
    }
    rewind(file);
    //*dbp = db;

    // go through the file line by line
    while (fgets(buffer, sizeof (buffer), file) != NULL) {
        // ignore comments
        if (strncmp(buffer, "#", 1) != 0) {
            // get host and value
            sscanf(buffer, "%[^'=']=%d", host, &val);
            // if no value we set it to 3
            if (val == 0) {
                val = 3;
            }
            // ad to database
            db_addtolist(info, host, val);
            // reset
            memset(host, 0, sizeof (host));
            memset(buffer, 0, sizeof (buffer));
            val = 0;
        }
    }
    fclose(file);
}

/* add host to listdb
 */
int db_addtolist(info *info, const char *buffer, int state) {
    DB *db;
    DBT key, data;
    const char *kv;
    int err = 0;
    void *allocData = NULL;

    db = info->list;

    kv = buffer;
    memset(&key, 0, sizeof (key));
    memset(&data, 0, sizeof (data));

    make_key(&key, kv);
    // retrieve the record
    err = dbget(db, &key, &data);
    
    // if we already have one, return
    if (err == 0) {
        return err;
    }
    if (0 != err && DB_NOTFOUND != err) {
        return err;
    }
    // if db is not found return
    if (DB_NOTFOUND == err) {
        data.size = 0;
    }

    // grow buffer if it's too small
    if (err = grow_buffer(&data, data.size + sizeof (state)), 0 != err) {
        return err;
    }

    // copy to another memory to have enough space
    memcpy((char *) data.data + data.size, &state, sizeof (state));
    data.size += sizeof (state);
    
    // store into database
    err = db->put(db, NULL, &key, &data, DB_NOOVERWRITE);

    return err;
}

/* checks the dnsbl's if the host is already listed
 */
int check_rbls(info *info) {
    FILE *conf;
    char buffer[1024] = "";
    char * response;
    char * domain;

    memset(buffer, 0, sizeof (buffer));

    // open dnsbl config
    conf = fopen("/usr/pam_abfp/rbl.conf", "a+");
    if (conf == NULL) {
        return 0;
    }
    // go through file
    while (fgets(buffer, sizeof (buffer), conf) != NULL) {
        // set domain
        domain = strtok(buffer, "\n");
        // ask the dnsbl if it is listed
        response = (char*) rblcheck(info->host, domain);
        if (response != NULL) {
            fclose(conf);
            return 1;
        }
        memset(buffer, 0, sizeof (buffer));
    }
    fclose(conf);
    return 0;
}

/* encryption function for the masterserver
 */
char * simple_xor(const char *msg, int key) {
    size_t messagelen = strlen(msg);
    size_t keylen = sizeof (key);

    char * encrypted = malloc(messagelen + 1);

    int i;
    // shift our message by the amount of key
    for (i = 0; i < messagelen; i++) {
        encrypted[i] = msg[i] ^ key;
    }
    encrypted[messagelen] = '\0';

    return encrypted;
}

/* decryption function for the masterserver
 */
char * simple_decrypt(char *msg, int key) {
    size_t messagelen = strlen(msg);
    size_t keylen = sizeof (key);

    char * encrypted = malloc(messagelen + 1);

    int i;
    // shift back by the amount of key
    for (i = 0; i < messagelen; i++) {
        encrypted[i] = msg[i] ^ key;
    }
    encrypted[messagelen] = '\0';

    return encrypted;
}

/* send the command to the masterserver to add a host to his database
 */
int send_server(info *info) {
    int sockfd = 0;
    char recvBuff[1024];
    char sendBuff[1024];
    struct sockaddr_in serv_addr;
    int ret;
    double p, g, a, b, c, d;
    p = 13;
    g = 2;

    srand(time(NULL));
    a = rand() % 10 + 1;
    d = pow(g, a);
    d = fmod(d, p);

    memset(recvBuff, 0, sizeof (recvBuff));
    memset(sendBuff, 0, sizeof (sendBuff));
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        //printf("\n Error : Could not create socket \n");
        return 1;
    }

    memset(&serv_addr, '0', sizeof (serv_addr));
    
    // set server information
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(5000);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    ret = connect(sockfd, (struct sockaddr *) &serv_addr, sizeof (serv_addr));
    if (ret < 0) {
        //printf("\n Error : Connect Failed \n");
        return 1;
    }

    // send to calculate shared secret
    snprintf(sendBuff, sizeof (sendBuff), "%f,%f,%f", p, g, d);
    ret = send(sockfd, sendBuff, strlen(sendBuff), 0);
    if (ret < 0) {
        return 1;
    }
    // answer for calculation
    ret = recv(sockfd, recvBuff, sizeof (recvBuff), 0);
    if (ret < 0) {
        return 1;
    }
    // c is our shared secret
    b = (double) atoi(recvBuff);
    c = pow(b, a);
    c = fmod(c, p);
    
    // create our send
    snprintf(sendBuff, sizeof (sendBuff), "%s block", info->host);
    // encrypt our send message
    char * encrypted = simple_xor(sendBuff, c);
    // send our encrypted message
    ret = send(sockfd, encrypted, strlen(encrypted), 0);
    if (ret < 0) {
        //printf("Send failed");
        return 1;
    }
    // receive answer from server
    ret = recv(sockfd, recvBuff, sizeof (recvBuff), 0);
    if (ret < 0) {
        //printf("recv failed");
        return 1;
    }
    // if answer has add, was successful added
    if (strstr(recvBuff, ADDE) != NULL) {
        // nicht gelistet
        //printf("%s",recvBuff);
        return 0;
    } else return 1;

}

/* check the masterserver if the host is already listed
 */
int check_server(info *info) {
    int sockfd = 0;
    char recvBuff[1024];
    char sendBuff[1024];
    struct sockaddr_in serv_addr;
    int ret;
    double p, g, a, b, c, d, mod;
    const char *serv = info->server;
    // get diffie-hellmann items
    p = info->p;
    g = info->g;
    mod = info->mod;
    //p = 13;
    //g = 2;

    srand(time(NULL));
    a = rand();
    a = fmod(a, mod + 1);
    d = pow(g, a);
    d = fmod(d, p);

    // create socket
    memset(recvBuff, 0, sizeof (recvBuff));
    memset(sendBuff, 0, sizeof (sendBuff));
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        //printf("\n Error : Could not create socket \n");
        return 1;
    }

    memset(&serv_addr, '0', sizeof (serv_addr));
    // set server info
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(5000);
    serv_addr.sin_addr.s_addr = inet_addr(serv);
    // connect to server
    ret = connect(sockfd, (struct sockaddr *) &serv_addr, sizeof (serv_addr));
    if (ret < 0) {
        //printf("\n Error : Connect Failed \n");
        return 1;
    }
    // send diffie-hellmann
    snprintf(sendBuff, sizeof (sendBuff), "%f,%f,%f", p, g, d);
    ret = send(sockfd, sendBuff, strlen(sendBuff), 0);
    if (ret < 0) {
        return 1;
    }
    // get answer to calculate shared secret
    ret = recv(sockfd, recvBuff, sizeof (recvBuff), 0);
    if (ret < 0) {
        return 1;
    }
    // calcualte shared secret
    b = (double) atoi(recvBuff);
    c = pow(b, a);
    c = fmod(c, p);

    // encrypt our message
    char * encrypted = simple_xor(info->host, c);

    // send our encrypted message
    snprintf(sendBuff, sizeof (sendBuff), "%s", encrypted);
    ret = send(sockfd, sendBuff, strlen(sendBuff), 0);
    if (ret < 0) {
        //printf("Send failed");
        return 1;
    }
    // receive answer from server
    ret = recv(sockfd, recvBuff, sizeof (recvBuff), 0);
    if (ret < 0) {
        //printf("recv failed");
        return 1;
    }
    // if the answer is not, it is not listed
    if (strstr(recvBuff, NOT) != NULL) {
        // nicht gelistet
        //printf("%s", recvBuff);
        return 2;
    } else return 0;
}

/* set information, not used anymore
 */
void setInfo(info *info, const char *user, const char *service, const char *host, const char *pw) {
    if (info == NULL) {
        return;
    }
    info->user = NULL;
    info->host = NULL;
    info->service = NULL;
    if (user != NULL) {
        info->user = strdup(user);
    }
    if (host != NULL) {
        info->host = strdup(host);
    }
    if (service != NULL) {
        info->service = strdup(service);
    }
    if (pw != NULL) {
        info->pw = strdup(pw);
    }
}

/* opens the environment for our db's
 */
int dbenvironment(const char *home, DB_ENV **dbenv, info * info) {
    int ret = 0;
    DB_ENV *env = NULL;
    // create environmet
    if ((ret = db_env_create(&env, 0)) != 0) {
        return ret;
    }
    env->set_errpfx(env, "pam-abfp");
    // open environment
    if ((ret = env->open(env, home, DB_CREATE | DB_INIT_MPOOL, 0)) != 0) {
        // if failed, close it
        env->close(env, 0);
        env = 0;
    }
    // else set it
    if (env != NULL) {
        info->dbenv = env;
        *dbenv = env;
    }

    return ret;
}

/* parse config for our masterserver
 */
void parse_conf(info *info) {
    FILE *conf;
    char buffer[100];
    // open config file
    conf = fopen("/usr/pam_abfp/pam_abpf.conf", "a+");
    if (conf == NULL) {
        return;
    }
    // read line by line of file
    while (fgets(buffer, sizeof (buffer), conf) != NULL) {
        // ignore comments
        if (strncmp(buffer, "#", 1) != 0) {
            // set infos for shared secret
            if (strncmp(buffer, "p", 1) == 0) {
                strtok(buffer, "=");
                const char *pi = strtok(NULL, ",");
                info->p = atof(pi);
                strtok(NULL, "=");
                const char *gi = strtok(NULL, ",");
                info->g = atof(gi);
                strtok(NULL, "=");
                const char *modi = strtok(NULL, "\n");
                info->mod = atoi(modi);
            } else {
                // set server address
                strtok(buffer, "=");
                char *serv = strtok(NULL, "\n");
                info->server = serv;
            }
        }
    }
    fclose(conf);
}

/* checks the login attempt, if needed adds to db or updates
 */
int check_attempt(info *info) {
    int err = 0;
    time_t tm = time(NULL);
    // check if host, user and service is not null
    if (info->user != NULL && info->service != NULL && info->host != NULL) {
        // checks the database for a record, if already blocked
        // or we have to add or update
        err = check_hostdb(info, "yes");

        //already in db and blocked
        if (err == -1) {
            goto user;
        }
        // not listed, so we add
        if (err == 0) {
            dbadd(info, tm, YES);
        }
        // update record
        if (err == 1) {
            dbupdate(info, tm, YES);
        }

user:
        // check db for user
        err = check_hostdb(info, "no");

        //already in db
        if (err == -1) {
            return -1;
        }
        // not listed so add
        if (err == 0) {
            dbadd(info, tm, NO);
        }
        // update user
        if (err == 1) {
            dbupdate(info, tm, NO);
        }
    }
    return 0;
}

/* writes to the log file
 */
void write_Log(const char *host, const char *status, const char *isHost) {
    char buffer[1000];
    time_t act_time;
    FILE *log;
    
    // if file is too large, we delte
    struct stat attr;
    if (stat("/usr/pam_abfp/PAM_ABFP_LOG.txt", &attr) == 0) {
        // delete if size of file is greater
        if (attr.st_size > 100000) {
            remove("/usr/pam_abfp/PAM_ABFP_LOG.txt");
        }
    }
    // open log file
    log = fopen("/usr/pam_abfp/PAM_ABFP_LOG", "a+");

    if (log != NULL) {
        // get time and write to file
        act_time = time(NULL);
        if (strcmp(status, "delete") == 0) {
            if (strcmp(isHost, "yes") == 0) {
                snprintf(buffer, sizeof (buffer), "Deleting %s from iptables : %s", host, ctime(&act_time));
                fputs(buffer, log);
            } else {
                snprintf(buffer, sizeof (buffer), "Deleting user %s from blocked group : %s", host, ctime(&act_time));
                fputs(buffer, log);
            }
        }
        if (strcmp(status, "delete") != 0) {
            if (strcmp(isHost, "yes") == 0) {
                snprintf(buffer, sizeof (buffer), "Adding %s to iptables : %s", host, ctime(&act_time));
                fputs(buffer, log);
            } else {
                snprintf(buffer, sizeof (buffer), "Adding user %s to group blocked : %s", host, ctime(&act_time));
                fputs(buffer, log);
            }
        }
    }
    fclose(log);
}