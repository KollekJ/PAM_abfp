/* rblcheck is taken from the programm rblcheck
 * it was written by Michael Tokarev 
 * and has GNU General Public License version 2.0 (GPLv2)
 */

#define RESULT_SIZE 4096

#ifndef PACKETSZ
#define PACKETSZ 512
#endif

#include "pam_abfp.h"

/* checks the dnsbl's if the host is alredy blocked
 */
char * rblcheck(char *ipadd, char * rbldomain)
{
    
	char * domain = NULL;
	char * result = NULL;
	u_char fixedans[ PACKETSZ ] = "";
	u_char * answer = NULL;
	int len;
        int a,b,c,d;
        // create the ip address
        if( sscanf( ipadd, "%d.%d.%d.%d", &a, &b, &c, &d ) != 4
		  || a < 0 || a > 255 || b < 0 || b > 255 || c < 0 || c > 255
		  || d < 0 || d > 255 )
		{
			return 0;
		}
        
	// 16 characters max in a dotted-quad address, plus 1 for null
	domain = ( char * )malloc( 17 + strlen( rbldomain ) );

	// Create a domain name, in reverse.
	sprintf( domain, "%d.%d.%d.%d.%s", d, c, b, a, rbldomain );

	// Make our DNS query.
	res_init();
	answer = fixedans;
	len = res_query( domain, C_IN, T_A, answer, PACKETSZ );

	// Was there a problem? If so, the domain doesn't exist.
	if( len == -1 )
		return result;

	if( len > PACKETSZ )
	{
		answer = malloc( len );
		len = res_query( domain, C_IN, T_A, answer, len );
		if( len == -1 )
			return result;
	}
        // already listed so we block
        result = ( char * )malloc( RESULT_SIZE );
	result[ 0 ] = '\0';
        return result;
}