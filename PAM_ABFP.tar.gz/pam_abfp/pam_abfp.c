/* ssh_block - a system-service for automatic blocking hosts and users
 * Copyright (C) 2012 Jürgen Kollek
 *
 * This program is part of a bachelor project.
 */

#include "pam_abfp.h"
/*
int main(void) {
    DB *utdb = NULL;
    DB *htdb = NULL;
    DB *hcdb = NULL;
    DB *ucdb = NULL;
    DB *hsdb = NULL;
    DB *usdb = NULL;
    DB *listdb = NULL;
    DB *timedb = NULL;
    int err = PAM_SUCCESS;
    int ret = 1;
    info * info2 = NULL;
    size_t si = 512;
  
  info2 = malloc(sizeof (info));
    
    if (info2 != NULL) {
        memset(info2, 0, sizeof (info));
    } else return PAM_BUF_ERR;

    //memset(info, 0, sizeof (info));
    DB_ENV *dbenv = NULL;
    err = dbenvironment("/usr/pam_abfp/db", &dbenv, info2);
    err = dbenvironment("/usr/pam_abfp/db", &dbenv, info2);
    err = dbopen("/usr/pam_abfp/db/hostcdb.db", "Host-Count", dbenv, &hcdb, info2);
    err = dbopen("/usr/pam_abfp/db/hosttdb.db", "Host-Time", dbenv, &htdb, info2);
    err = dbopen("/usr/pam_abfp/db/usertdb.db", "User-Time", dbenv, &utdb, info2);
    err = dbopen("/usr/pam_abfp/db/usercdb.db", "User-Count", dbenv, &ucdb, info2);
    err = dbopen("/usr/pam_abfp/db/usersdb.db", "User-State", dbenv, &usdb, info2);
    err = dbopen("/usr/pam_abfp/db/hostsdb.db", "Host-State", dbenv, &hsdb, info2);
    err = dbopen("/usr/pam_abfp/db/list.db", "List-DB", dbenv, &listdb, info2);
    err = dbopen("/usr/pam_abfp/db/timeold.db", "Old-Time", dbenv, &timedb, info2);

    const char *host = "planetlab1.upc.es";
    const char *user = "test";
    const char *service = "sshd";
    const char *pw = "t3st";
    info2->host = strdup(host);
    info2->user = strdup(user);
    info2->service = strdup(service);
    info2->pw = strdup(pw);

    parse_conf(info2);

    ret = check_server(info2);
    if (ret == 0) {
        time_t tnow;
        tnow = time(NULL);
        command(info2->host, "add", YES, tnow);
        return PAM_AUTH_ERR;
    }

    get_pw(info2);

    ret = encrypt_pw(info2);
    if (ret == 2) {
        return PAM_AUTH_ERR;
    }
    
    FILE *log;
    char buffer[100];
    log = fopen("/usr/pam_abfp/test123.txt","a+");
    if(log != NULL){
        snprintf(buffer,sizeof(buffer),"vor parse list\n");
        fputs(buffer,log);
        fclose(log);
    }
    
    parse_list(info2);

    ret = check_rbls(info2);
    if (ret == 1) {
        time_t tnow;
        tnow = time(NULL);
        command(info2->host, "add", YES, tnow);
        return PAM_AUTH_ERR;
    }

    check_unbans(info2, YES);
    check_unbans(info2, NO);

    err = check_attempt(info2);
    
    check_count(info2, YES);
    check_count(info2, NO);

    htdb->close(htdb, 0);
    htdb = 0;
    hcdb->close(hcdb, 0);
    hcdb = 0;
    hsdb->close(hsdb, 0);
    hsdb = 0;
    ucdb->close(ucdb, 0);
    ucdb = 0;
    usdb->close(usdb, 0);
    usdb = 0;
    timedb->close(timedb, 0);
    timedb = 0;
    utdb->close(utdb, 0);
    utdb = 0;
    free(info2);

    //dbenv->remove(dbenv,"/usr/pam_abfp/db",DB_FORCE);
    //free(info);
    //free(info);

    return PAM_SUCCESS;

psa_fail:
    utdb->close(utdb, 0);
    ucdb->close(ucdb, 0);
    usdb->close(usdb, 0);
    htdb->close(htdb, 0);
    hsdb->close(hsdb, 0);
    hcdb->close(hcdb, 0);
    return err;

    exit(EXIT_SUCCESS);
}*/

/* closes pam info and Databases
 */
static void cleanup(pam_handle_t *pamh, void *data, int err) {
    DB* db;

    if (NULL != data) {
        info *info = data;

        db = info->ucdb;
        db->close(db, 0);
        db = info->usdb;
        db->close(db, 0);
        db = info->utdb;
        db->close(db, 0);
        db = info->hcdb;
        db->close(db, 0);
        db = info->hsdb;
        db->close(db, 0);
        db = info->htdb;
        db->close(db, 0);
        db = info->list;
        db->close(db, 0);
        db = info->time;
        db->close(db, 0);
    }
}

/* Function called by authentication module
 */
PAM_EXTERN int pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    
    /* Our variables
     */
    DB *utdb = NULL;
    DB *htdb = NULL;
    DB *hcdb = NULL;
    DB *ucdb = NULL;
    DB *hsdb = NULL;
    DB *usdb = NULL;
    DB *listdb = NULL;
    DB *timedb = NULL;
    info *abpf_info = NULL;
    DB_ENV *dbenv = NULL;
    int err = PAM_SUCCESS;
    int ret = 0;
    int parsed_list=0;

    // initialize our structur
    if (abpf_info = malloc(sizeof (info)), NULL == abpf_info) {
        return PAM_BUF_ERR;
    }
    // check if list db already exists, so we don't have to reread the db
    err = access("/usr/pam_abfp/db/list.db",F_OK);
    if(err == 0){
        parsed_list = 1;
    }

    memset(abpf_info, 0, sizeof (info));

    abpf_info->pamh = pamh;

    // Open our different Databases
    err = dbenvironment("/usr/pam_abfp/db", &dbenv, abpf_info);
    err = dbopen("/usr/pam_abfp/db/hostcdb.db", "Host-Count", dbenv, &hcdb, abpf_info);
    err = dbopen("/usr/pam_abfp/db/hosttdb.db", "Host-Time", dbenv, &htdb, abpf_info);
    err = dbopen("/usr/pam_abfp/db/usertdb.db", "User-Time", dbenv, &utdb, abpf_info);
    err = dbopen("/usr/pam_abfp/db/usercdb.db", "User-Count", dbenv, &ucdb, abpf_info);
    err = dbopen("/usr/pam_abfp/db/usersdb.db", "User-State", dbenv, &usdb, abpf_info);
    err = dbopen("/usr/pam_abfp/db/hostsdb.db", "Host-State", dbenv, &hsdb, abpf_info);
    err = dbopen("/usr/pam_abfp/db/list.db", "List-DB", dbenv, &listdb, abpf_info);
    err = dbopen("/usr/pam_abfp/db/timeold.db", "Old-Time", dbenv, &timedb, abpf_info);

    // retrieve information from pam
    if (err = pam_get_item(abpf_info->pamh, PAM_USER, (const void **) &abpf_info->user), PAM_SUCCESS != err) {
        goto psa_fail;
    }
    
    if (err = pam_get_item(abpf_info->pamh, PAM_SERVICE, (const void **) &abpf_info->service), PAM_SUCCESS != err) {
        goto psa_fail;
    }
    
    if (err = pam_get_item(abpf_info->pamh, PAM_RHOST, (const void **) &abpf_info->host), PAM_SUCCESS != err) {
        goto psa_fail;
    }/*
    if (err = pam_get_item(info->pamh, PAM_AUTHTOK, (const void **) &info->pw), PAM_SUCCESS != err) {
        goto psa_fail;
    }*/

    // parse the config of the server
    parse_conf(abpf_info);
    
    // check if the host is already listed on the masterserver
    ret = check_server(abpf_info);
    // if yes then we add it to our db
    if (ret == 0) {
        time_t tnow;
        tnow = time(NULL);
        command(abpf_info->host, "add", YES, tnow);
        return PAM_AUTH_ERR;
    }
    
    // get the password which was used 
    ret = get_pw(abpf_info);
    
    // if we could retrieve the password, we check how similiar it is
    if(ret == 0){
        ret = encrypt_pw(abpf_info);
    }
    // if it is similiar to the right one, we cancel here
    if (ret == 2) {
        return PAM_SUCCESS;
    }
    
    // check dnsbl's and if the host is already listed we block him also
    ret = check_rbls(abpf_info);
    if (ret == 1) {
        time_t tnow;
        tnow = time(NULL);
        command(abpf_info->host, "add", YES, tnow);
        return PAM_AUTH_ERR;
    }
    
    // check if we have some user or hosts to unblock
    check_unbans(abpf_info, YES);
    check_unbans(abpf_info, NO);
    
    // if the listdb already exists, we can skip this step
    if(parsed_list == 0){
        parse_list(abpf_info);
    }
    // check our incoming login attempt
    err = check_attempt(abpf_info);
    
    // closes the databases to flush to the drive
    htdb->close(htdb, 0);
    hcdb->close(hcdb, 0);
    hsdb->close(hsdb, 0);
    ucdb->close(ucdb, 0);
    usdb->close(usdb, 0);
    listdb->close(listdb, 0);
    timedb->close(timedb, 0);
    utdb->close(utdb, 0);
    free(abpf_info);

    // if host or user is blocked we return an error, else we return success
    if (err == -1) {
        return PAM_AUTH_ERR;
    } else {
        return PAM_SUCCESS;
    }

    // if something failed at start
psa_fail:
    utdb->close(utdb, 0);
    ucdb->close(ucdb, 0);
    usdb->close(usdb, 0);
    htdb->close(htdb, 0);
    hsdb->close(hsdb, 0);
    hcdb->close(hcdb, 0);
    timedb->close(timedb, 0);
    return PAM_AUTH_ERR;
}

PAM_EXTERN int pam_sm_setcred(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    return pam_set_data(pamh, DATA_NAME, NULL, cleanup);
}

/* this function is used by the session module
 */
PAM_EXTERN int pam_sm_open_session(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    // our variables we use
    DB *utdb = NULL;
    DB *htdb = NULL;
    DB *hcdb = NULL;
    DB *ucdb = NULL;
    DB *hsdb = NULL;
    DB *usdb = NULL;
    DB *listdb = NULL;
    DB *timedb = NULL;
    DB_ENV *dbenv = NULL;
    info *abfp_info = NULL;
    int err = PAM_SUCCESS;
    int ret = 0;
    
    // initialize our structur
    if (abfp_info = malloc(sizeof (info)), NULL == abfp_info) {
        return PAM_BUF_ERR;
    }
    
    memset(abfp_info, 0, sizeof (info));

    abfp_info->pamh = pamh;
    
    // open our used databases
    err = dbenvironment("/usr/pam_abfp/db", &dbenv, abfp_info);
    err = dbopen("/usr/pam_abfp/db/hostcdb.db", "Host-Count", dbenv, &hcdb, abfp_info);
    err = dbopen("/usr/pam_abfp/db/hosttdb.db", "Host-Time", dbenv, &htdb, abfp_info);
    err = dbopen("/usr/pam_abfp/db/usertdb.db", "User-Time", dbenv, &utdb, abfp_info);
    err = dbopen("/usr/pam_abfp/db/usercdb.db", "User-Count", dbenv, &ucdb, abfp_info);
    err = dbopen("/usr/pam_abfp/db/usersdb.db", "User-State", dbenv, &usdb, abfp_info);
    err = dbopen("/usr/pam_abfp/db/hostsdb.db", "Host-State", dbenv, &hsdb, abfp_info);
    err = dbopen("/usr/pam_abfp/db/list.db", "List-DB", dbenv, &listdb, abfp_info);
    err = dbopen("/usr/pam_abfp/db/timeold.db", "Old-Time", dbenv, &timedb, abfp_info);

    // retrieve information from pam
    if (err = pam_get_item(abfp_info->pamh, PAM_USER, (const void **) &abfp_info->user), PAM_SUCCESS != err) {
        goto psa_fail;
    }

    if (err = pam_get_item(abfp_info->pamh, PAM_SERVICE, (const void **) &abfp_info->service), PAM_SUCCESS != err) {
        goto psa_fail;
    }

    if (err = pam_get_item(abfp_info->pamh, PAM_RHOST, (const void **) &abfp_info->host), PAM_SUCCESS != err) {
        goto psa_fail;
    }
    
    // parse the server config
    parse_conf(abfp_info);
    
    // check for the given host or user to decrease count,...
    check_count(abfp_info, YES);
    check_count(abfp_info, NO);
     
    // close our databases
    hcdb->close(hcdb, 0);
    hsdb->close(hsdb, 0);
    utdb->close(utdb, 0);
    ucdb->close(ucdb, 0);
    usdb->close(usdb, 0);
    timedb->close(timedb, 0);
    htdb->close(htdb, 0);
    free(abfp_info);

    return PAM_SUCCESS;

    // if something went wrong we close all
psa_fail:
    utdb->close(utdb, 0);
    ucdb->close(ucdb, 0);
    usdb->close(usdb, 0);
    htdb->close(htdb, 0);
    hsdb->close(hsdb, 0);
    hcdb->close(hcdb, 0);
    return PAM_SESSION_ERR;
}

PAM_EXTERN int pam_sm_close_session(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    return PAM_SUCCESS;
}

/* Init structure for static modules */

#ifdef PAM_STATIC
struct pam_module _pam_abl_modstruct = {
    MODULE_NAME,
    pam_sm_authenticate,
    pam_sm_setcred,
    pam_sm_open_session,
    pam_sm_close_session,
    NULL
};
#endif